var animalnames = ["Rats", "Spiders", "Snakes", "Bats", "Wild Boars", "Wolves", "Bears", "Crocodiles", "Tigers", "Elephants"];
var singlenames = ["Rat", "Spider", "Snake", "Bat", "Wild Boar", "Wolf", "Bear", "Crocodile", "Tiger", "Elephant"];
// content.js
chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {
		if( request.message === "clicked_browser_action" ) {
			if ($("body").hasClass("map")) {
				var tables = $("#troop_info > tbody");
				if (tables.length){
					var url = "http://travian.kirilloid.ru/warsim2.php#a:uUb#d:p500r3#r3u";
					var units = "";
					var rows = tables.eq(0).children('tr');
					var j = 0;
					for (var i = 0; i < animalnames.length; i++) {
						var desc = $.trim(rows.eq(j).children('.desc').text());
						var val = $.trim(rows.eq(j).children('.val').text());
						if (desc == animalnames[i] || desc == singlenames[i]) {
							units += val + ",";
							j++;
						}
					}
					// This line is new!
					chrome.runtime.sendMessage({"message": "open_new_tab", "url": url + units + "U"});
				}
			}
		}
	}
);